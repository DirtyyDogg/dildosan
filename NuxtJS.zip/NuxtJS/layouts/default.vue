<template>
    <div>
        <Navbar />
        <h6>Hier lag mauwmauw</h6>
        <Nuxt />
    </div>
</template>

<script>
import Navbar from '~/components/site-partials/Navbar'
export default {
    components: {
        Navbar
    }
}
</script>