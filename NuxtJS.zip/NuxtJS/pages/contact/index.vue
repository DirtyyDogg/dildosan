<template>
    <h1>Als goed is zie je dit op /contact</h1>
</template>