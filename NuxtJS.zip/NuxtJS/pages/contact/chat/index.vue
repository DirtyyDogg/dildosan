<template>
    <h1>Als goed is zie je deze op /contacten/chat</h1>
</template>